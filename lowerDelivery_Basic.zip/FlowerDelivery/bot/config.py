# Токен вашего бота (замените на ваш токен)
BOT_TOKEN = "8158195727:AAEW5n4ttKNEBAFs4PfdxlN1usI9zfR_-Io"
