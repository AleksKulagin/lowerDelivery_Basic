WORK_HOURS_START = 9  # 9 утра
WORK_HOURS_END = 18  # 6 вечера